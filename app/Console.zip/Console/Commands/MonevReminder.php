<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Carbon\Carbon;
use App\Models\Opd;
use App\Models\Monev;

class MonevReminder extends Command
{
    protected $signature = 'monev:reminder';
    protected $description = 'Reminder WhatsApp Monev per Triwulan ke OPD (Filter Tahun Renja)';

    // public function handle()
    // {
    //     // 1. Tentukan Waktu Sistem Saat Ini
    //     $now = Carbon::now();
    //     $bulan = $now->month;
        
    //     // Tahun Sistem (Ini yang akan jadi patokan filter ke tabel rencana_kerjas)
    //     $tahun = $now->year; 

    //     // Tentukan Triwulan & Key
    //     if ($bulan <= 3) {
    //         $triwulanKey = "1"; $namaTriwulan = 'I';
    //     } elseif ($bulan <= 6) {
    //         $triwulanKey = "2"; $namaTriwulan = 'II';
    //     } elseif ($bulan <= 9) {
    //         $triwulanKey = "3"; $namaTriwulan = 'III';
    //     } else {
    //         $triwulanKey = "4"; $namaTriwulan = 'IV';
    //     }

    //     $this->info("--- Proses Reminder Triwulan: {$namaTriwulan} Tahun {$tahun} ---");

    //     // 2. Ambil OPD Aktif
    //     $opds = Opd::whereNotNull('no_tlp')
    //         ->where('no_tlp', '!=', '')
    //         ->where('delete_at', '0')
    //         ->get();

    //     foreach ($opds as $opd) {
            
    //         // 3. Ambil data Monev + Filter Tahun Rencana Kerja
    //         // Kita gunakan 'whereHas' untuk memastikan hanya mengambil data
    //         // yang tahun-nya di tabel 'rencana_kerjas' SAMA dengan tahun sistem ($tahun).
    //         $daftarMonev = Monev::with('rencanakerja')
    //                             ->where('id_opd', $opd->id)
    //                             ->whereHas('rencanakerja', function($query) use ($tahun) {
    //                                 $query->where('tahun', $tahun);
    //                             })
    //                             ->get();

    //         // Jika OPD ini tidak punya program satupun di tahun ini, skip loop (lanjut ke OPD berikutnya)
    //         if ($daftarMonev->isEmpty()) {
    //             $this->info("Skip {$opd->nama}: Tidak ada program di tahun {$tahun}");
    //             continue; 
    //         }

    //         $programBelumLengkap = [];

    //         // Cek setiap Program yang lolos filter tahun
    //         foreach ($daftarMonev as $mv) {
    //             $dokumen = $mv->dokumen_anggaran ?? [];

    //             // Cek Triwulan
    //             if (!isset($dokumen[$triwulanKey]) || empty($dokumen[$triwulanKey])) {
    //                 // Ambil nama dari relasi
    //                 $namaProgram = $mv->rencanakerja->nama_program ?? 'Program Tanpa Nama';
    //                 $programBelumLengkap[] = $namaProgram;
    //             }
    //         }

    //         // 4. Susun & Kirim Pesan
    //         if (count($programBelumLengkap) > 0) {
                
    //             // --- KASUS: ADA YANG BELUM UPLOAD ---
                
    //             $listProgramString = "";
    //             foreach ($programBelumLengkap as $index => $prog) {
    //                 $no = $index + 1;
    //                 $listProgramString .= "\n" . $no . ". " . $prog;
    //             }

    //             // Tahun di pesan ini valid karena data sudah difilter pakai whereHas di atas
    //             $pesan = "📢 *Reminder RAD PG*\n\n"
    //                    . "Yth. *{$opd->nama}*,\n\n"
    //                    . "Berdasarkan data sistem, kami mendapati bahwa *Dokumen Anggaran Triwulan {$namaTriwulan} Tahun {$tahun}* pada program berikut:\n"
    //                    . "*{$listProgramString}*\n\n"
    //                    . "*BELUM* diunggah.\n\n"
    //                    . "Mohon kesediaannya untuk segera melengkapi data tersebut.\n\n"
    //                    . "Terima kasih.";

    //             $statusLog = "BELUM (" . count($programBelumLengkap) . " Program)";

    //         } else {
                
    //             // --- KASUS: SEMUA PROGRAM TAHUN INI SUDAH LENGKAP ---
                
    //             $pesan = "✅ *Konfirmasi RAD PG*\n\n"
    //                    . "Yth. *{$opd->nama}*,\n\n"
    //                    . "Terima kasih, seluruh data *Dokumen Anggaran Triwulan {$namaTriwulan} Tahun {$tahun}* Anda telah lengkap diterima di sistem.\n\n"
    //                    . "Mohon pastikan kembali data yang diinput sudah sesuai.\n\n"
    //                    . "Hormat Kami, Admin.";

    //             $statusLog = "LENGKAP";
    //         }

    //         // 5. Eksekusi
    //         $this->info("Mengirim ke: {$opd->nama} -> Status: {$statusLog}");
    //         $this->kirimWA($opd->no_tlp, $pesan);
    //     }

    //     $this->info('Semua proses selesai.');
    // }
    public function handle()
{
    // 1. Tentukan Waktu & Filter Tahun
    $now = Carbon::now();
    $bulan = $now->month;
    $tahun = $now->year; // Tahun sistem = Tahun Filter Renja

    // Tentukan Triwulan
    if ($bulan <= 3) {
        $triwulanKey = "1"; $namaTriwulan = 'I';
    } elseif ($bulan <= 6) {
        $triwulanKey = "2"; $namaTriwulan = 'II';
    } elseif ($bulan <= 9) {
        $triwulanKey = "3"; $namaTriwulan = 'III';
    } else {
        $triwulanKey = "4"; $namaTriwulan = 'IV';
    }

    $this->info("--- Laporan Status Triwulan {$namaTriwulan} Tahun {$tahun} ---");

    // 2. Ambil OPD
    $opds = Opd::whereNotNull('no_tlp')
        ->where('no_tlp', '!=', '')
        ->where('delete_at', '0')
        ->get();

    foreach ($opds as $opd) {
        
        // 3. Ambil data Monev (Hanya tahun ini)
        $daftarMonev = Monev::with('rencanakerja')
                            ->where('id_opd', $opd->id)
                            ->whereHas('rencanakerja', function($query) use ($tahun) {
                                $query->where('tahun', $tahun);
                            })
                            ->get();

        if ($daftarMonev->isEmpty()) {
            continue; // Skip jika tidak ada program tahun ini
        }

        // Variabel untuk menampung list text
        $listProgramString = "";
        $jumlahBelum = 0;

        // 4. Loop Semua Program untuk dibuat Daftarnya
        foreach ($daftarMonev as $index => $mv) {
            $dokumen = $mv->dokumen_anggaran ?? [];
            $namaProgram = $mv->rencanakerja->nama_program ?? 'Program Tanpa Nama';
            
            // Cek Status
            if (!isset($dokumen[$triwulanKey]) || empty($dokumen[$triwulanKey])) {
                // KONDISI: BELUM
                $icon = "❌";
                $ket = "BELUM";
                $jumlahBelum++; // Hitung berapa yang bolong
            } else {
                // KONDISI: SUDAH
                $icon = "✅";
                $ket = "SUDAH";
            }

            // Susun baris per program
            // Contoh: 1. Program Jalan (❌ BELUM)
            $no = $index + 1;
            $listProgramString .= "\n" . $no . ". " . $namaProgram . " (" . $icon . " " . $ket . ")";
        }

        // 5. Susun Pesan WA (Satu pesan memuat semua status)
        
        // Header Pesan
        $pesan = "📢 *Laporan Status RAD PG*\n\n"
               . "Yth. *{$opd->nama}*,\n\n"
               . "Berikut adalah status kelengkapan *Dokumen Anggaran Triwulan {$namaTriwulan} Tahun {$tahun}* pada sistem:\n"
               . "----------------------------------"
               . "{$listProgramString}\n" // List semua program masuk di sini
               . "----------------------------------\n\n";

        // Footer Pesan (Menyesuaikan kondisi)
        if ($jumlahBelum > 0) {
            $pesan .= "⚠️ Masih terdapat *{$jumlahBelum} program* yang *BELUM* diunggah (tanda ❌).\n"
                    . "Mohon segera melengkapi data tersebut.\n\n";
        } else {
            $pesan .= "👏 Terpantau semua program *SUDAH LENGKAP* (tanda ✅).\n"
                    . "Terima kasih atas kerjasamanya.\n\n";
        }

        $pesan .= "Terima kasih.\nAdmin Monev.";

        // 6. Kirim
        $this->info("Mengirim ke: {$opd->nama} -> (Belum: {$jumlahBelum})");
        $this->kirimWA($opd->no_tlp, $pesan);
    }

    $this->info('Semua proses selesai.');
}

    private function kirimWA($no, $pesan)
    {
        $no = preg_replace('/^0/', '62', $no);

        $data = http_build_query([
            'target' => $no,
            'message' => $pesan,
            'countryCode' => '62',
        ]);

        $options = [
            'http' => [
                'header'  => 
                    "Content-type: application/x-www-form-urlencoded\r\n" .
                    "Authorization: " . env('FONNTE_TOKEN') . "\r\n",
                'method'  => 'POST',
                'content' => $data,
                'ignore_errors' => true,
            ],
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
            ],
        ];

        try {
            $context = stream_context_create($options);
            file_get_contents('https://api.fonnte.com/send', false, $context);
        } catch (\Exception $e) {
            $this->error("Gagal kirim: " . $e->getMessage());
        }
    }
}